from __future__ import unicode_literals

from django.apps import AppConfig


class LoginTestConfig(AppConfig):
    name = 'login_test'
